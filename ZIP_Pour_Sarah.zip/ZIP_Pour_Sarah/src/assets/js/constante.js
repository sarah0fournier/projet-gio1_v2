// NE PAS SUPPRIMER !!!!!!!!!!!!!!!!!!!!!!!!!!

// config.js

// Layers venant de map.geo.admin
// URL de base pour les services WMS
export const wmsUrlGeoadmin = "https://wms.geo.admin.ch/";
// URL de base pour les attributions
export const attributionUrlGeoadmin = "https://www.geo.admin.ch/fr/home.html";

// Layers venant de geodienst
// URL de base pour les services WMS
export const wmsUrlGeodienst = "https://geodienste.ch/db/av_0/fra?";
// URL de base pour les attributions
export const attributionUrlGeodienst = "https://geodienste.ch/db/av_0/fra?";

export const projectionCode = "EPSG:2056";


